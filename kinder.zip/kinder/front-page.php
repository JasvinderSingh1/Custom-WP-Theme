<?php
get_header();
?>

<div class="grid">
			<div class="grid-sizer"></div>
				<div class="grid-item-width1 item">
					<div class="current-event"><a href="#">NOVEMBER 2018 <br> Aktueller Veranstaltungskalender</a></div>
				</div>
				
				<div class="grid-item-width2 item">
					<div class="top-topic-container">
						<div class="top-topic-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/top-topic.jpg">
						</div><!--top-topic-image-->
						<div class="event-detail">
							<div class="event-name">FESTE & FEIERN</div>
							<h2>Ich gehe mit meiner Laterne... </h2>
							<p>Einfach finden, was Spaß im November macht...</p>
							
						</div><!--event-detail-->
					</div><!--top-topic-container-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="fav-event"><a href="#">Unsere Lieblinge <br> im NOVEMBER</a></div>
				</div>
				
				
					<div class="grid-item-width1 item">
					<div class="event-box">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/sport.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">SPIEL & SPORT</div>
							<h2>Alle Wetter, was für ein Spielplatz: Der Märchenspielplatz!</h2>
							<p>Auch bei Wetter, das alles andere als märchenhaft ist, kann man auf dem Neuköllner Märchen...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
					</div>
					
					<div class="grid-item-width1 item">
					<div class="event-box box-color2">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/nature.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">NATUR & LAND</div>
							<h2>Berliner Märchentage: Babajaga im Ökowerk</h2>
							<p>Folgt dem Faden der mächtigsten Hexe des Ostens und entdeckt auch ihre gute Seite. Eine...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="event-box box-color3">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/life.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">LEBEN & LERNEN</div>
							<h2>Im Dunkeln lässt sich munkeln - Deutsches Spionagemuseum</h2>
							<p>Hier steht Blindtext. Hier steht Blindtext. Hier steht Blindtext. Hier steht Blindtext. Hier steht Blindtext...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				
					
					<div class="grid-item-width1 item">
					<div class="event-box box-color1">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/parties.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">FESTE & FEIERN</div>
							<h2>Sankt Martinstag – Von knusprigen Gänsen und Stutenkerlen</h2>
							<p>Ein traditionelles Hefegebäck zu St. Martin ist der Stutenkerl. Wir stellen euch ein kinderleichtes ...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="event-box box-color6">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/buy-pay.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">KAUFEN & SCHENKEN</div>
							<h2>Unsere Geschenktipps für die kuschelige Jahreszeit</h2>
							<p>Adventskalender, bunte Gummistiefel und gemütlicheDecken – die schönsten Gelegenheiten...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="new-event">
						<a href="#">St. Martin 2018 – <br> die schönsten Laternenumzüge in BERLIN >></a>
					</div>
				</div>
				
				
				
				<div class="grid-item-width2 item">
					<div class="event-box box-color4">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/art.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">KUNST & KULTUR</div>
							<h2>Realistischer & größer: Das Pergamon-Panorama kehrt nach Berlin zurück</h2>
							<p>Das Pergamonpanorama von Yadegar Asisi kehrt zurück nach Berlin – aktueller, schöner, größer als die...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				
				<div class="grid-item-width1 item">
					<div class="event-box box-color2">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/nature-land.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">NATUR & LAND</div>
							<h2>Fast wie Ferien: November-Wochenenden auf dem Land</h2>
							<p>Ein bisschen Wind und eine Wiese: Mehr braucht es nicht. Und Platz gibt es dafür reichlich in...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="event-box box-color5">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/u-kids.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">Ü12 & U16</div>
							<h2>GoVolonteer – Soziales Engagement, was zu dir passt</h2>
							<p>Ein traditionelles Hefegebäck zu St. Martin ist der Stutenkerl. Wir stellen euch ein kinderleichtes...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
				<div class="grid-item-width1 item">
					<div class="event-box">
						<div class="event-image">
							<img src="<?php bloginfo('template_directory'); ?>/images/game.png">
						</div><!--event-image-->
						<div class="event-detail">
							<div class="event-name">SPIEL & SPORT</div>
							<h2>Fliegen wie im Hurrikan</h2>
							<p>Direkt am Berliner Stadtrand findet ihr in der Hurricane Factory einen der weltweit größten Windkanäle...</p>
							<a href="#">mehr lesen</a>
						</div><!--event-detail-->
					</div><!--event-box-->
				</div>
				
			</div><!--row-->

<?php
get_footer();
?>