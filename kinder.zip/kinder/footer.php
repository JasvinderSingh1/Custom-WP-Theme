</div><!--container-->
	</div><!--main-content-->

<div class="footer-container">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="footer-link">
					<ul>
						<li><a href="#">Über uns</a></li>
						<li><a href="#">Für Anbieter</a></li>
						<li><a href="#">Impressum</a></li>
						<li><a href="#">Kontakt</a></li>
						<li><a href="#">Jobs</a></li>
						<li><a href="#">Datenschutz</a></li>
						<li><a href="#">Faq</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-4">
				<div class="row">
					<div class="col-sm-6">
						<div class="newsletter">
							<h2>NEWSLETTER</h2>
							<input type="text" placeholder="EMAIL ADDRESSE">
							<button>ANMELDEN</button>
						</div><!--newsletter-->
					</div>
					<div class="col-sm-6">
						<div class="footer-social">
							<ul>
								<li class="facebook"><a href="#"></a></li>
								<li class="twitter"><a href="#"></a></li>
								<li class="insta"><a href="#"></a></li>
							</ul>
						</div><!--footer-social-->
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--footer-container-->
  
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/masonry/4.2.2/masonry.pkgd.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/wow.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>
<?php wp_footer(); ?>
  </body>
</html>