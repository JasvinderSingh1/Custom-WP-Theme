<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kinder Leicht Berlin</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,400,500,600,700,900" rel="stylesheet">
	<link href="<?php bloginfo('template_directory'); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php bloginfo('template_directory'); ?>/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php bloginfo('template_directory'); ?>/css/style.css" rel="stylesheet">
	<?php wp_head(); ?>
  </head>
  <body>
  	<div class="header wow fadeIn" data-wow-duration="2s">
		<div class="container clearfix">
			<div class="row">
				<div class="col-lg-2">
					<div class="logo">
						<a href="<?php echo home_url(); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="kinder logo"></a>
					</div><!--logo-->
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" 
					aria-controls="navbarColor01" aria-expanded="false"	aria-label="Toggle navigation">
                                    <span class="navTrigger">
                                        <i></i>
                                        <i></i>
                                        <i></i>
                                    </span>
                    </button>
				</div>
				<div class="col-lg-10 navbar-collapse collapse" id="navbarColor01">
					<div class="main-menu">
						<!--<ul class="mobile-nav clearfix">
							<li><a href="#">Tipps <br> & Termine</a></li>
							<li><a href="#">Spiel <br> & Sport</a></li>
							<li><a href="#">KULTUR <br> & KUNST</a></li>
							<li><a href="#">Leben <br> & Lernen</a></li>
							<li><a href="#">FESTE <br> & FEIERN</a></li>
							<li><a href="#">KAUFEN <br> & SCHENKEN</a></li>
							<li><a href="#">NATUR <br> & Land</a></li>
							<li><a href="#">Ü 12 <br> & U 16</a></li>
						</ul>-->
						<?php
						    wp_nav_menu(array('menu'=> 'Main Menu','menu_class' => 'mobile-nav clearfix'));
						?>
					</div><!--main-menu-->
				</div>
			</div><!--row-->
			
			<div class="header-select">
				<div class="row">
					<div class="col-md-2">
						<div class="select-heading">
							<span>Einfach finden,</span>
							<span>was SpaSS macht!</span>
						</div><!--select-heading-->
					</div>
					<div class="col-md-2">
						<div class="select-box">
							<label>ALTER des kindes</label>
							<select><option>ALLE</option><option>ALLE</option></select>
						</div><!--select-box-->
					</div>
					<div class="col-md-2">
						<div class="select-box">
							<label>Was?</label>
							<select><option>TIPPS & TERMINE</option><option>TIPPS & TERMINE</option></select>
						</div><!--select-box-->
					</div>
					<div class="col-md-2">
						<div class="select-box">
							<label>Wo?</label>
							<select><option>Berlin & Brandenburg</option><option>Berlin & Brandenburg</option></select>
						</div><!--select-box-->
					</div>
					<div class="col-md-2">
						<div class="select-box">
							<label>Wann?</label>
							<select><option>MO, 8. September 2018</option><option>MO, 8. September 2018</option></select>
						</div><!--select-box-->
					</div>
					<div class="col-md-2">
						<label></label>
						<button>SUCHE</button>
					</div>
				</div>
			</div>
			
		</div><!--container-->
	</div><!--header-->
	
	<div class="main-content">
		<div class="container">