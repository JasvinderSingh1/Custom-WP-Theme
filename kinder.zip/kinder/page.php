<?php get_header();?>
<div class="row">
<?php
    while(have_posts()){
          the_post();
          echo '<h1>'.get_the_title().'</h1>';
          echo '<div>'.get_the_content().'</div>';
    }
?>
</div>
<?php get_footer();?>