jQuery(document).ready(function(){
	
	new WOW().init();
});
jQuery(window).on('load', function(){
    jQuery('.grid').masonry({
			// options
			itemSelector : '.item',
			columnWidth: '.grid-sizer',
			percentPosition: true
		});
});

